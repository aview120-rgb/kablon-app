/* קבלון — קריאת טקסט מקבצים: PDF (pdf.js), תמונות (זיהוי טקסט OCR בעברית ובאנגלית) ו-HTML */
(function (root) {
  'use strict';

  const loaded = {};
  function loadScript(src) {
    if (!loaded[src]) {
      loaded[src] = new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = src;
        s.onload = resolve;
        s.onerror = () => { delete loaded[src]; reject(new Error('טעינה נכשלה: ' + src)); };
        document.head.appendChild(s);
      });
    }
    return loaded[src];
  }

  async function pdfjs() {
    await loadScript('vendor/pdf.min.js');
    root.pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';
    return root.pdfjsLib;
  }

  let ocrWorkerPromise = null;
  async function ocrWorker() {
    if (!ocrWorkerPromise) {
      ocrWorkerPromise = (async () => {
        await loadScript('vendor/tesseract.min.js');
        const base = new URL('vendor/', location.href).href;
        return root.Tesseract.createWorker(['heb', 'eng'], 1, {
          workerPath: base + 'worker.min.js',
          corePath: base + 'tesseract-core/',
          langPath: base + 'lang',
          gzip: true,
          workerBlobURL: false
        });
      })().catch(e => { ocrWorkerPromise = null; throw e; });
    }
    return ocrWorkerPromise;
  }

  async function ocr(canvasOrBlob) {
    const w = await ocrWorker();
    const { data } = await w.recognize(canvasOrBlob);
    return data.text || '';
  }

  function loadImage(blob) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('לא ניתן לפתוח את התמונה')); };
      img.src = url;
    });
  }

  function drawScaled(src, w, h, max) {
    const scale = Math.min(1, max / Math.max(w, h));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w * scale));
    c.height = Math.max(1, Math.round(h * scale));
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(src, 0, 0, c.width, c.height);
    return c;
  }

  const toBlob = (canvas, q) => new Promise(r => canvas.toBlob(r, 'image/jpeg', q || 0.85));

  function htmlToText(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    doc.querySelectorAll('script,style,head').forEach(n => n.remove());
    doc.querySelectorAll('br').forEach(n => n.replaceWith('\n'));
    doc.querySelectorAll('p,div,tr,li,h1,h2,h3,h4,table').forEach(n => n.append('\n'));
    doc.querySelectorAll('td,th').forEach(n => n.append(' '));
    return (doc.body ? doc.body.textContent : '').replace(/\n\s*\n+/g, '\n').trim();
  }

  async function pdfText(pdf) {
    const out = [];
    const pages = Math.min(pdf.numPages, 6);
    for (let p = 1; p <= pages; p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent();
      // מקבצים פריטים לשורות לפי הגובה בעמוד
      const rows = [];
      for (const it of tc.items) {
        if (!it.str || !it.str.trim()) continue;
        const y = it.transform[5], x = it.transform[4];
        let row = rows.find(r => Math.abs(r.y - y) < 3);
        if (!row) { row = { y, items: [] }; rows.push(row); }
        row.items.push({ x, s: it.str });
      }
      rows.sort((a, b) => b.y - a.y);
      for (const r of rows) {
        const rtl = r.items.some(i => /[֐-׿]/.test(i.s));
        r.items.sort((a, b) => rtl ? b.x - a.x : a.x - b.x);
        out.push(r.items.map(i => i.s).join(' '));
      }
    }
    return out.join('\n');
  }

  /**
   * extract(blob, opts) → { text, file (Blob לשמירה), thumb (Blob), mime, kind }
   * opts.onStatus(msg) לעדכון התקדמות
   */
  async function extract(blob, opts) {
    opts = opts || {};
    const status = opts.onStatus || (() => {});
    const name = (blob.name || '').toLowerCase();
    let mime = blob.type || '';
    if (!mime) {
      if (name.endsWith('.pdf')) mime = 'application/pdf';
      else if (/\.(jpe?g|png|webp|heic|gif|bmp)$/.test(name)) mime = 'image/' + name.split('.').pop().replace('jpg', 'jpeg');
      else if (/\.html?$/.test(name)) mime = 'text/html';
      else if (name.endsWith('.txt')) mime = 'text/plain';
    }

    if (mime === 'application/pdf') {
      status('קורא PDF…');
      const lib = await pdfjs();
      const pdf = await lib.getDocument({ data: new Uint8Array(await blob.arrayBuffer()) }).promise;
      let text = await pdfText(pdf);
      const page = await pdf.getPage(1);
      const vp = page.getViewport({ scale: 2 });
      const canvas = document.createElement('canvas');
      canvas.width = vp.width; canvas.height = vp.height;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      if (text.replace(/\s/g, '').length < 30) {
        status('PDF סרוק — מזהה טקסט…');
        text = await ocr(canvas);
      }
      const thumb = await toBlob(drawScaled(canvas, canvas.width, canvas.height, 360), 0.75);
      return { text, file: blob, thumb, mime, kind: 'pdf' };
    }

    if (mime.startsWith('image/')) {
      status('מעבד תמונה…');
      const img = await loadImage(blob);
      const big = drawScaled(img, img.naturalWidth, img.naturalHeight, 2000);
      const file = blob.size > 900000 || !/jpe?g|png/.test(mime) ? await toBlob(big, 0.85) : blob;
      const thumb = await toBlob(drawScaled(img, img.naturalWidth, img.naturalHeight, 360), 0.75);
      status('מזהה טקסט בתמונה… (בפעם הראשונה זה לוקח קצת יותר)');
      const text = await ocr(big);
      return { text, file, thumb, mime: file.type || mime, kind: 'image' };
    }

    if (mime === 'text/html' || mime === 'text/plain') {
      const raw = await blob.text();
      const text = mime === 'text/html' ? htmlToText(raw) : raw;
      return { text, file: blob, thumb: null, mime, kind: mime === 'text/html' ? 'html' : 'text' };
    }

    throw new Error('סוג קובץ לא נתמך: ' + (mime || name || 'לא ידוע'));
  }

  async function sha256(blob) {
    const buf = await blob.arrayBuffer();
    const h = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(h)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  root.Extract = { extract, htmlToText, sha256, loadScript, isSupported: f => /pdf|image|html|text\/plain/.test(f.type || '') || /\.(pdf|jpe?g|png|webp|gif|bmp|html?|txt)$/i.test(f.name || '') };
})(typeof self !== 'undefined' ? self : this);
