/* קבלון — סריקת Gmail לאיתור קבלות וחשבוניות (קריאה בלבד, ישירות מהטלפון ל-Google) */
(function (root) {
  'use strict';
  const SCOPE = 'https://www.googleapis.com/auth/gmail.readonly';
  const API = 'https://gmail.googleapis.com/gmail/v1/users/me';

  const QUERY_WORDS = [
    'קבלה', 'חשבונית', '"חשבונית מס"', '"אישור תשלום"', '"אישור הזמנה"', '"פירוט חיוב"',
    'receipt', 'invoice', '"order confirmation"', '"payment received"', '"your order"', '"payment confirmation"', 'billing'
  ];

  let token = null, tokenExp = 0, tokenClient = null;

  async function ensureGis() {
    if (root.google && root.google.accounts && root.google.accounts.oauth2) return;
    await root.Extract.loadScript('https://accounts.google.com/gsi/client');
  }

  async function getToken(clientId, interactive) {
    if (token && Date.now() < tokenExp - 60000) return token;
    if (!clientId) throw new Error('חסר מזהה חיבור ל-Google. ראה הוראות בהגדרות.');
    await ensureGis();
    return new Promise((resolve, reject) => {
      tokenClient = root.google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: SCOPE,
        callback: (resp) => {
          if (resp.error) return reject(new Error(resp.error_description || resp.error));
          token = resp.access_token;
          tokenExp = Date.now() + (resp.expires_in || 3600) * 1000;
          resolve(token);
        },
        error_callback: (e) => reject(new Error(e && e.type === 'popup_closed' ? 'החלון נסגר לפני שהחיבור הושלם' : 'החיבור ל-Google נכשל'))
      });
      tokenClient.requestAccessToken({ prompt: interactive ? 'consent' : '' });
    });
  }

  async function api(path, params) {
    const url = new URL(API + path);
    if (params) Object.entries(params).forEach(([k, v]) => v != null && url.searchParams.set(k, v));
    const r = await fetch(url, { headers: { Authorization: 'Bearer ' + token } });
    if (r.status === 401) { token = null; throw new Error('פג תוקף החיבור ל-Gmail. לחץ שוב על "סרוק".'); }
    if (!r.ok) throw new Error('שגיאה מ-Gmail (' + r.status + ')');
    return r.json();
  }

  function b64urlToBytes(s) {
    const b64 = s.replace(/-/g, '+').replace(/_/g, '/');
    const bin = atob(b64 + '==='.slice((b64.length + 3) % 4));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  const b64urlToText = s => new TextDecoder('utf-8').decode(b64urlToBytes(s));

  function header(msg, name) {
    const h = (msg.payload.headers || []).find(h => h.name.toLowerCase() === name.toLowerCase());
    return h ? h.value : '';
  }

  function walk(part, acc) {
    if (!part) return acc;
    const mime = part.mimeType || '';
    if (part.filename && part.body && (part.body.attachmentId || part.body.data)) {
      if (/pdf|image\//i.test(mime) || /\.(pdf|jpe?g|png)$/i.test(part.filename)) acc.attachments.push(part);
    } else if (mime === 'text/html' && part.body && part.body.data) acc.html.push(b64urlToText(part.body.data));
    else if (mime === 'text/plain' && part.body && part.body.data) acc.plain.push(b64urlToText(part.body.data));
    (part.parts || []).forEach(p => walk(p, acc));
    return acc;
  }

  function senderName(from) {
    const m = from.match(/^\s*"?([^"<]+?)"?\s*<([^>]+)>/);
    if (m) return { name: m[1].trim(), email: m[2].trim() };
    return { name: '', email: from.trim() };
  }

  function isoDate(ms) {
    const d = new Date(+ms);
    return isNaN(d) ? '' : new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  }

  /**
   * scan({ clientId, days, onProgress, onItem, isKnown })
   *  onItem({ key, blob, filename, hints, emailSubject, emailFrom }) — נקרא לכל קבלה שנמצאה
   *  isKnown(key) — כדי לא לייבא שוב מה שכבר יובא
   */
  async function scan(opts) {
    await getToken(opts.clientId, !token);
    const days = opts.days || 90;
    const q = '(' + QUERY_WORDS.join(' OR ') + ') newer_than:' + days + 'd -in:spam -in:trash -category:promotions';
    const ids = [];
    let pageToken = null;
    do {
      const res = await api('/messages', { q, maxResults: 100, pageToken });
      (res.messages || []).forEach(m => ids.push(m.id));
      pageToken = res.nextPageToken;
      opts.onProgress && opts.onProgress('נמצאו ' + ids.length + ' מיילים אפשריים…');
    } while (pageToken && ids.length < 1000);

    let found = 0, done = 0;
    for (const id of ids) {
      done++;
      opts.onProgress && opts.onProgress('בודק מייל ' + done + ' מתוך ' + ids.length + ' · נמצאו ' + found + ' קבלות');
      if (await opts.isKnown('gmail:' + id)) continue;
      let msg;
      try { msg = await api('/messages/' + id, { format: 'full' }); } catch (e) { continue; }
      const from = senderName(header(msg, 'From'));
      const subject = header(msg, 'Subject');
      const hints = { vendor: from.name || from.email.split('@')[1] || '', date: isoDate(msg.internalDate) };
      const parts = walk(msg.payload, { attachments: [], html: [], plain: [] });
      const base = { emailSubject: subject, emailFrom: from.name ? from.name + ' <' + from.email + '>' : from.email, hints };

      if (parts.attachments.length) {
        for (const a of parts.attachments) {
          const key = 'gmail:' + id + ':' + (a.filename || a.partId);
          if (await opts.isKnown(key)) continue;
          let data = a.body.data;
          if (!data) { try { data = (await api('/messages/' + id + '/attachments/' + a.body.attachmentId)).data; } catch (e) { continue; } }
          const bytes = b64urlToBytes(data);
          const mime = a.mimeType && a.mimeType !== 'application/octet-stream' ? a.mimeType : (/\.pdf$/i.test(a.filename) ? 'application/pdf' : 'image/jpeg');
          const blob = new File([bytes], a.filename || 'attachment', { type: mime });
          if (await opts.onItem(Object.assign({ key, blob, filename: a.filename, bodyText: parts.plain.join('\n') }, base))) found++;
        }
      } else {
        // קבלה בגוף המייל (בלי קובץ מצורף) — שומרים את המייל עצמו
        const html = parts.html.join('\n');
        const body = html || parts.plain.join('\n');
        if (!body) continue;
        const doc = '<!doctype html><meta charset="utf-8"><base target="_blank"><div style="font-family:system-ui;padding:8px;border-bottom:1px solid #ccc;margin-bottom:8px"><b>' +
          escapeHtml(subject) + '</b><br><small>' + escapeHtml(base.emailFrom) + ' · ' + hints.date + '</small></div>' + (html || '<pre style="white-space:pre-wrap">' + escapeHtml(body) + '</pre>');
        const blob = new File([doc], (subject || 'email').slice(0, 60) + '.html', { type: 'text/html' });
        if (await opts.onItem(Object.assign({ key: 'gmail:' + id, blob, filename: blob.name, requireConfidence: 0.55, subjectText: subject }, base))) found++;
      }
    }
    return { scanned: ids.length, found };
  }

  function escapeHtml(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

  function disconnect() {
    if (token && root.google && root.google.accounts) root.google.accounts.oauth2.revoke(token, () => {});
    token = null; tokenExp = 0;
  }

  root.Gmail = { scan, disconnect, isConnected: () => !!token };
})(typeof self !== 'undefined' ? self : this);
