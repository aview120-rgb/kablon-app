/* קבלון — לוגיקת האפליקציה */
(function () {
  'use strict';
  const VERSION = '1.0.0';
  const P = window.ReceiptParser;
  const $ = s => document.querySelector(s);
  const CAT = Object.fromEntries(P.CATEGORIES.map(c => [c.id, c]));
  const DOC = Object.fromEntries(P.DOC_TYPES.map(d => [d.id, d]));
  const SOURCES = { gmail: '📧 מייל', whatsapp: '💬 וואטסאפ', share: '📲 שיתוף', camera: '📷 צילום', file: '📄 קובץ', manual: '✍️ ידני' };
  const CUR = { ILS: '₪', USD: '$', EUR: '€', GBP: '£' };
  const MONTHS = ['ינואר', 'פברואר', 'מרץ', 'אפריל', 'מאי', 'יוני', 'יולי', 'אוגוסט', 'ספטמבר', 'אוקטובר', 'נובמבר', 'דצמבר'];

  const state = { receipts: [], month: monthKey(new Date()), filter: 'all', q: '', view: 'home' };
  const urls = new Map();

  function monthKey(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); }
  function shiftMonth(key, n) { const [y, m] = key.split('-').map(Number); return monthKey(new Date(y, m - 1 + n, 1)); }
  function monthName(key) { const [y, m] = key.split('-').map(Number); return MONTHS[m - 1] + ' ' + y; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function money(n, cur) {
    if (n == null || isNaN(n)) return '—';
    return (CUR[cur || 'ILS'] || cur + ' ') + Number(n).toLocaleString('he-IL', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
  }
  function fmtDate(iso) { if (!iso) return 'ללא תאריך'; const [y, m, d] = iso.split('-'); return d + '/' + m + '/' + y; }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  const rMonth = r => (r.date || (r.createdAt || '').slice(0, 10)).slice(0, 7);

  /* ---------- הודעות התקדמות ---------- */
  let progressDepth = 0;
  function progress(msg) {
    const el = $('#progress');
    if (msg) { $('#progressText').textContent = msg; el.classList.add('show'); }
    else el.classList.remove('show');
  }
  let toastTimer;
  function toast(msg, ms) {
    progress(null);
    const el = $('#progress');
    $('#progressText').textContent = msg;
    el.querySelector('.spin').style.display = 'none';
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.classList.remove('show'); el.querySelector('.spin').style.display = ''; }, ms || 3200);
  }
  function busy(msg) { clearTimeout(toastTimer); $('#progress .spin').style.display = ''; progress(msg); }

  /* ---------- טעינה ---------- */
  async function load() {
    state.receipts = await DB.all('receipts');
    state.receipts.sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.createdAt || '').localeCompare(a.createdAt || ''));
  }

  async function fileUrl(id, kind) {
    const k = id + ':' + kind;
    if (urls.has(k)) return urls.get(k);
    const f = await DB.get('files', id);
    const blob = f && (kind === 'thumb' ? f.thumb : f.blob);
    if (!blob) return null;
    const u = URL.createObjectURL(blob);
    urls.set(k, u);
    return u;
  }

  /* ---------- ייבוא ---------- */
  const queue = [];
  let working = false;

  async function isDuplicate(hash) {
    if (!hash) return null;
    const found = await DB.byIndex('receipts', 'hash', hash);
    return found[0] || null;
  }

  /** מייבא קובץ אחד: מזהה טקסט, מנתח, שומר. מחזיר את הרשומה או null */
  async function importBlob(blob, meta) {
    meta = meta || {};
    const hash = await Extract.sha256(blob);
    if (await isDuplicate(hash)) return { dup: true };
    const id = uid();
    let ex;
    try {
      ex = await Extract.extract(blob, { onStatus: s => busy((meta.label ? meta.label + ' · ' : '') + s) });
    } catch (e) {
      const rec = { id, createdAt: new Date().toISOString(), source: meta.source || 'file', sourceKey: meta.key || '', hash, filename: blob.name || '', mime: blob.type, status: 'error', error: e.message, category: 'other', docType: 'receipt', currency: 'ILS', date: meta.hints && meta.hints.date || '' };
      await DB.put('files', { id, blob, thumb: null });
      await DB.put('receipts', rec);
      return rec;
    }
    let parsed = P.parse(ex.text, meta.hints);
    if (parsed.total == null && meta.extraText) {
      const alt = P.parse(meta.extraText + '\n' + ex.text, meta.hints);
      if (alt.total != null) parsed = Object.assign(alt, { text: parsed.text });
    }
    if (meta.subjectText) parsed.confidence = Math.max(parsed.confidence, P.parse(meta.subjectText + '\n' + ex.text).confidence);
    if (meta.requireConfidence && parsed.confidence < meta.requireConfidence) return { skipped: true };

    const learned = parsed.vendor && (await DB.getSetting('vendorCats', {}))[parsed.vendor.toLowerCase()];
    if (learned) parsed.category = learned;
    const rec = {
      id, createdAt: new Date().toISOString(),
      source: meta.source || 'file', sourceKey: meta.key || '', hash,
      filename: blob.name || '', mime: ex.mime, kind: ex.kind,
      vendor: parsed.vendor, date: parsed.date, total: parsed.total, vat: parsed.vat, vatEstimated: parsed.vatEstimated,
      currency: parsed.currency, docNumber: parsed.docNumber, businessId: parsed.businessId,
      docType: parsed.docType, category: parsed.category, confidence: parsed.confidence,
      text: (parsed.text || '').slice(0, 20000), notes: '',
      emailSubject: meta.emailSubject || '', emailFrom: meta.emailFrom || '',
      status: parsed.total == null || !parsed.date || parsed.confidence < 0.5 ? 'review' : 'ready'
    };
    await DB.put('files', { id, blob: ex.file, thumb: ex.thumb });
    await DB.put('receipts', rec);
    return rec;
  }

  async function expandZip(file) {
    await Extract.loadScript('vendor/jszip.min.js');
    const zip = await window.JSZip.loadAsync(file);
    const out = [];
    const entries = Object.values(zip.files).filter(f => !f.dir && !/(^|\/)(__MACOSX|\.)/.test(f.name));
    for (const e of entries) {
      const name = e.name.split('/').pop();
      if (!/\.(pdf|jpe?g|png|webp)$/i.test(name)) continue;
      const ext = name.split('.').pop().toLowerCase();
      const type = ext === 'pdf' ? 'application/pdf' : 'image/' + (ext === 'jpg' ? 'jpeg' : ext);
      out.push(new File([await e.async('blob')], name, { type }));
    }
    return out;
  }

  /** ייבוא קבוצת קבצים (מהעלאה, צילום, שיתוף מוואטסאפ) */
  async function importFiles(files, source) {
    let list = [];
    const srcOf = new Map();
    for (const f of files) {
      if (/zip/.test(f.type) || /\.zip$/i.test(f.name || '')) {
        busy('פותח קובץ ZIP…');
        try {
          const inner = await expandZip(f);
          const wa = /whatsapp/i.test(f.name || '') || inner.some(x => /-WA\d+/i.test(x.name));
          inner.forEach(x => { list.push(x); srcOf.set(x, wa ? 'whatsapp' : source); });
        } catch (e) { toast('לא הצלחתי לפתוח את ה-ZIP'); }
      } else { list.push(f); srcOf.set(f, /-WA\d+/i.test(f.name || '') ? 'whatsapp' : source); }
    }
    // מסננים תמונות זעירות (אימוג'י, לוגו, סטיקרים)
    list = list.filter(f => !(/^image\//.test(f.type) && f.size < 12000));
    if (!list.length) { toast('לא נמצאו קבלות בקבצים ששותפו'); return; }
    let added = 0, dups = 0, review = 0, i = 0, lastRec = null;
    for (const f of list) {
      i++;
      const label = list.length > 1 ? 'קובץ ' + i + ' מתוך ' + list.length : '';
      busy(label || 'מעבד…');
      const r = await importBlob(f, { source: srcOf.get(f), label });
      if (r && r.dup) dups++;
      else if (r && r.id) { added++; lastRec = r; if (r.status !== 'ready') review++; }
      await load(); render();
    }
    progress(null);
    let msg = added ? 'נוספו ' + added + ' קבלות' : 'לא נוספו קבלות חדשות';
    if (dups) msg += ' · ' + dups + ' כבר קיימות';
    if (review) msg += ' · ' + review + ' דורשות בדיקה';
    toast(msg, 4500);
    if (added === 1 && list.length === 1 && lastRec) openReceipt(lastRec.id);
  }

  /* קבצים ששותפו לאפליקציה (מוואטסאפ, Gmail, הגלריה) נשמרים ב-inbox ע"י ה-Service Worker */
  async function processInbox() {
    const items = await DB.all('inbox');
    if (!items.length) return;
    await DB.clear('inbox');
    const files = [];
    let text = '';
    for (const it of items) {
      (it.files || []).forEach(f => files.push(f));
      if (it.text) text += it.text + '\n';
    }
    if (files.length) await importFiles(files, 'share');
    else if (text.trim()) {
      const blob = new File([text], 'הודעה.txt', { type: 'text/plain' });
      await importBlobAndOpen(blob, 'share');
    }
  }

  async function importBlobAndOpen(blob, source) {
    busy('מעבד…');
    const r = await importBlob(blob, { source });
    progress(null);
    await load(); render();
    if (r && r.dup) toast('הקבלה הזו כבר קיימת');
    else if (r && r.id) openReceipt(r.id);
  }

  /* ---------- Gmail ---------- */
  async function gmailScan() {
    const clientId = (await DB.getSetting('clientId', '')).trim();
    if (!clientId) {
      go('settings');
      toast('כדי לסרוק את המייל צריך קודם להגדיר חיבור ל-Google (פעם אחת)', 5000);
      $('#view-settings details').open = true;
      return;
    }
    const days = +(await DB.getSetting('scanDays', 90));
    const skipped = new Set(await DB.getSetting('gmailSkipped', []));
    busy('מתחבר ל-Gmail…');
    try {
      const res = await Gmail.scan({
        clientId, days,
        onProgress: busy,
        isKnown: async key => skipped.has(key) || (await DB.byIndex('receipts', 'sourceKey', key)).length > 0,
        onItem: async item => {
          if (/^image\//.test(item.blob.type) && item.blob.size < 15000) { skipped.add(item.key); return false; }
          const r = await importBlob(item.blob, {
            source: 'gmail', key: item.key, hints: item.hints, extraText: item.bodyText,
            emailSubject: item.emailSubject, emailFrom: item.emailFrom,
            requireConfidence: item.requireConfidence, subjectText: item.subjectText || item.emailSubject
          });
          if (!r || r.skipped || r.dup) { skipped.add(item.key); return false; }
          return true;
        }
      });
      await DB.setSetting('gmailSkipped', Array.from(skipped).slice(-5000));
      await DB.setSetting('gmailLast', new Date().toISOString());
      await load(); render();
      toast(res.found ? 'נמצאו ' + res.found + ' קבלות חדשות במייל 🎉' : 'אין קבלות חדשות במייל', 5000);
    } catch (e) {
      await DB.setSetting('gmailSkipped', Array.from(skipped).slice(-5000));
      await load(); render();
      toast(e.message || 'הסריקה נכשלה', 6000);
    }
  }

  /* ---------- תצוגה ---------- */
  function go(view) {
    state.view = view;
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
    document.querySelectorAll('nav.bottom [data-nav]').forEach(b => b.classList.toggle('on', b.dataset.nav === view));
    $('#title').textContent = { home: 'קבלון', list: 'הקבלות שלי', settings: 'הגדרות' }[view];
    history.replaceState(view, '', location.pathname + '#' + view);
    window.scrollTo(0, 0);
    render();
  }

  function sums(list) {
    const by = {};
    let vat = 0;
    for (const r of list) {
      if (r.total == null) continue;
      const sign = r.docType === 'credit' ? -1 : 1;
      by[r.currency || 'ILS'] = (by[r.currency || 'ILS'] || 0) + sign * r.total;
      if ((r.currency || 'ILS') === 'ILS' && r.vat) vat += sign * r.vat;
    }
    return { by, vat };
  }

  async function itemHtml(r) {
    const thumb = r.kind === 'image' || r.kind === 'pdf' ? await fileUrl(r.id, 'thumb') : null;
    const icon = r.kind === 'html' ? '✉️' : r.kind === 'text' ? '💬' : (CAT[r.category] || CAT.other).icon;
    let badge = '';
    if (r.status === 'review') badge = ' <span class="badge warn">לבדיקה</span>';
    if (r.status === 'error') badge = ' <span class="badge err">שגיאה</span>';
    return '<button class="item" data-open="' + r.id + '">' +
      '<span class="thumb" style="' + (thumb ? 'background-image:url(' + thumb + ')' : '') + '">' + (thumb ? '' : icon) + '</span>' +
      '<span class="mid"><span class="v">' + esc(r.vendor || r.filename || 'ללא שם') + badge + '</span>' +
      '<span class="meta">' + fmtDate(r.date) + ' · ' + esc((CAT[r.category] || CAT.other).name) + ' · ' + (SOURCES[r.source] || '') + '</span></span>' +
      '<span class="amt num">' + (r.docType === 'credit' ? '-' : '') + money(r.total, r.currency) + '</span></button>';
  }

  async function renderHome() {
    $('#monthLabel').textContent = monthName(state.month);
    const list = state.receipts.filter(r => rMonth(r) === state.month);
    const s = sums(list);
    $('#sTotal').textContent = money(s.by.ILS || 0, 'ILS');
    $('#sOther').textContent = Object.entries(s.by).filter(([c]) => c !== 'ILS').map(([c, v]) => '+ ' + money(v, c)).join('  ');
    $('#sVat').textContent = money(s.vat, 'ILS');
    $('#sCount').textContent = list.length;

    const review = state.receipts.filter(r => r.status === 'review' || r.status === 'error');
    $('#reviewCard').classList.toggle('hidden', !review.length);
    $('#reviewCount').textContent = review.length === 1 ? 'קבלה אחת לבדיקה' : review.length + ' קבלות לבדיקה';

    const byCat = {};
    for (const r of list) if ((r.currency || 'ILS') === 'ILS' && r.total) byCat[r.category] = (byCat[r.category] || 0) + r.total;
    const cats = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
    const max = cats.length ? cats[0][1] : 1;
    $('#catCard').classList.toggle('hidden', !cats.length);
    $('#cats').innerHTML = cats.map(([id, v]) => {
      const c = CAT[id] || CAT.other;
      return '<div class="cat-row" data-cat="' + id + '"><span>' + c.icon + '</span><span><span class="nm">' + c.name + '</span><span class="bar"><i style="width:' + Math.max(3, v / max * 100) + '%"></i></span></span><b class="num small">' + money(v) + '</b></div>';
    }).join('');

    const last = await DB.getSetting('gmailLast', '');
    $('#gmailSub').textContent = last ? 'נסרק לאחרונה ' + fmtDate(last.slice(0, 10)) : 'איסוף קבלות מ-Gmail';

    const recent = list.slice(0, 6);
    $('#recent').innerHTML = recent.length ? (await Promise.all(recent.map(itemHtml))).join('') :
      '<div class="empty"><div class="big">🧾</div>אין עדיין קבלות ב' + monthName(state.month) + '.<br>אפשר לסרוק את המייל, לשתף מוואטסאפ או לצלם קבלה.</div>';
  }

  async function renderList() {
    const chips = [['all', 'הכול'], ['review', '⚠️ לבדיקה'], ['month', 'החודש']]
      .concat(Object.entries(SOURCES).filter(([k]) => state.receipts.some(r => r.source === k)).map(([k, v]) => ['src:' + k, v]))
      .concat(P.CATEGORIES.filter(c => state.receipts.some(r => r.category === c.id)).map(c => ['cat:' + c.id, c.icon + ' ' + c.name]));
    $('#filterChips').innerHTML = chips.map(([k, v]) => '<button class="chip' + (state.filter === k ? ' on' : '') + '" data-filter="' + k + '">' + esc(v) + '</button>').join('');

    const q = state.q.trim().toLowerCase();
    let list = state.receipts.filter(r => {
      const f = state.filter;
      if (f === 'review' && !(r.status === 'review' || r.status === 'error')) return false;
      if (f === 'month' && rMonth(r) !== monthKey(new Date())) return false;
      if (f.startsWith('src:') && r.source !== f.slice(4)) return false;
      if (f.startsWith('cat:') && r.category !== f.slice(4)) return false;
      if (q) {
        const hay = [r.vendor, r.docNumber, r.businessId, r.notes, r.filename, r.emailSubject, r.emailFrom, r.total, (CAT[r.category] || {}).name, fmtDate(r.date)].join(' ').toLowerCase();
        if (hay.indexOf(q) === -1 && (r.text || '').toLowerCase().indexOf(q) === -1) return false;
      }
      return true;
    });
    if (!list.length) {
      $('#listBody').innerHTML = '<div class="empty"><div class="big">🔍</div>' + (state.receipts.length ? 'לא נמצאו קבלות' : 'עוד אין קבלות. לחץ על ＋ כדי להוסיף.') + '</div>';
      return;
    }
    const groups = new Map();
    for (const r of list) { const k = rMonth(r) || 'none'; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(r); }
    let html = '';
    for (const [k, rs] of groups) {
      const s = sums(rs);
      html += '<div class="group-h"><span>' + (k === 'none' ? 'ללא תאריך' : monthName(k)) + ' · ' + rs.length + '</span><span class="num">' + money(s.by.ILS || 0) + '</span></div><div class="list">' + (await Promise.all(rs.map(itemHtml))).join('') + '</div>';
    }
    $('#listBody').innerHTML = html;
  }

  async function renderSettings() {
    $('#clientId').value = await DB.getSetting('clientId', '');
    $('#scanDays').value = String(await DB.getSetting('scanDays', 90));
    $('#theme').value = await DB.getSetting('theme', '');
    $('#originCode').textContent = location.origin;
    $('#ver').textContent = VERSION;
    if (navigator.storage && navigator.storage.estimate) {
      const e = await navigator.storage.estimate();
      $('#storageInfo').textContent = state.receipts.length + ' קבלות · ' + (e.usage / 1048576).toFixed(1) + ' MB בשימוש';
    }
  }

  let renderPending = false;
  function render() {
    if (renderPending) return;
    renderPending = true;
    requestAnimationFrame(async () => {
      renderPending = false;
      if (state.view === 'home') await renderHome();
      else if (state.view === 'list') await renderList();
      else if (state.view === 'settings') await renderSettings();
    });
  }

  /* ---------- חלונות (Sheet) ---------- */
  function openSheet(html) {
    $('#sheet').innerHTML = '<div class="grab"></div>' + html;
    $('#sheetWrap').classList.add('open');
    $('#sheet').scrollTop = 0;
    if (history.state !== 'sheet') history.pushState('sheet', '');
  }
  function closeSheet(fromPop) {
    if (!$('#sheetWrap').classList.contains('open')) return;
    $('#sheetWrap').classList.remove('open');
    $('#sheet').innerHTML = '';
    if (!fromPop && history.state === 'sheet') history.back();
  }

  function selectOpts(obj, sel) { return Object.entries(obj).map(([k, v]) => '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + esc(v) + '</option>').join(''); }

  async function openReceipt(id) {
    const r = await DB.get('receipts', id);
    if (!r) return;
    let preview = '';
    if (r.kind === 'image') preview = '<img src="' + await fileUrl(id, 'blob') + '" alt="">';
    else if (r.kind === 'pdf') preview = '<img src="' + await fileUrl(id, 'thumb') + '" alt="">';
    else if (r.kind === 'html') { const f = await DB.get('files', id); preview = '<iframe sandbox="allow-popups allow-popups-to-escape-sandbox" srcdoc="' + esc(await f.blob.text()) + '"></iframe>'; }
    else preview = '<pre class="text" style="margin:0;width:100%;border:0">' + esc(r.text || r.error || '') + '</pre>';

    openSheet(
      '<div class="sheet-head"><h2>' + esc(r.vendor || 'קבלה') + '</h2><button class="icon-btn" data-act="close" aria-label="סגירה">✕</button></div>' +
      (r.status === 'review' ? '<p class="small" style="margin:4px 0 8px"><span class="badge warn">לבדיקה</span> חלק מהפרטים לא זוהו בוודאות. בדוק ותקן אם צריך, ואז שמור.</p>' : '') +
      (r.status === 'error' ? '<p class="small" style="margin:4px 0 8px"><span class="badge err">שגיאה</span> ' + esc(r.error) + '. אפשר למלא את הפרטים ידנית.</p>' : '') +
      '<div class="preview">' + preview + '</div>' +
      '<div class="row" style="margin-top:8px"><button class="btn ghost" data-act="open-file" data-id="' + id + '">פתיחת המקור</button><button class="btn ghost" data-act="share-file" data-id="' + id + '">שיתוף</button></div>' +
      '<form id="recForm" data-id="' + id + '">' +
      '<div class="field"><label>שם העסק / ספק</label><input type="text" name="vendor" value="' + esc(r.vendor) + '"></div>' +
      '<div class="grid2"><div class="field"><label>סכום כולל</label><input type="number" inputmode="decimal" step="0.01" name="total" value="' + (r.total ?? '') + '"></div>' +
      '<div class="field"><label>מטבע</label><select name="currency">' + selectOpts({ ILS: '₪ שקל', USD: '$ דולר', EUR: '€ יורו', GBP: '£ ליש"ט' }, r.currency || 'ILS') + '</select></div></div>' +
      '<div class="grid2"><div class="field"><label>תאריך</label><input type="date" name="date" value="' + esc(r.date) + '"></div>' +
      '<div class="field"><label>מע"מ' + (r.vatEstimated ? ' (משוער)' : '') + '</label><input type="number" inputmode="decimal" step="0.01" name="vat" value="' + (r.vat ?? '') + '"></div></div>' +
      '<div class="field"><label>קטגוריה</label><select name="category">' + selectOpts(Object.fromEntries(P.CATEGORIES.map(c => [c.id, c.icon + ' ' + c.name])), r.category) + '</select></div>' +
      '<div class="grid2"><div class="field"><label>סוג מסמך</label><select name="docType">' + selectOpts(Object.fromEntries(P.DOC_TYPES.map(d => [d.id, d.name])), r.docType) + '</select></div>' +
      '<div class="field"><label>מספר מסמך</label><input type="text" name="docNumber" dir="ltr" value="' + esc(r.docNumber) + '"></div></div>' +
      '<div class="field"><label>ח.פ / עוסק מורשה</label><input type="text" name="businessId" inputmode="numeric" dir="ltr" value="' + esc(r.businessId) + '"></div>' +
      '<div class="field"><label>הערות</label><textarea name="notes">' + esc(r.notes) + '</textarea></div>' +
      '<button class="btn full" type="submit">שמירה</button></form>' +
      '<p class="small muted">מקור: ' + (SOURCES[r.source] || '') + (r.emailFrom ? ' · ' + esc(r.emailFrom) : '') + (r.emailSubject ? '<br>נושא: ' + esc(r.emailSubject) : '') + (r.filename ? '<br>קובץ: ' + esc(r.filename) : '') + '</p>' +
      (r.text ? '<details><summary>הטקסט שזוהה</summary><pre class="text">' + esc(r.text) + '</pre></details>' : '') +
      '<div class="row" style="margin-top:10px">' + (r.kind === 'image' || r.kind === 'pdf' ? '<button class="btn ghost" data-act="reparse" data-id="' + id + '">זיהוי מחדש</button>' : '') + '<button class="btn danger" data-act="delete" data-id="' + id + '">מחיקה</button></div>'
    );
  }

  async function saveForm(form) {
    const id = form.dataset.id;
    const r = await DB.get('receipts', id);
    const fd = new FormData(form);
    const num = v => (v === '' || v == null ? null : Math.round(parseFloat(v) * 100) / 100);
    const vatBefore = r.vat;
    Object.assign(r, {
      vendor: fd.get('vendor').trim(), total: num(fd.get('total')), currency: fd.get('currency'), date: fd.get('date'),
      vat: num(fd.get('vat')), category: fd.get('category'), docType: fd.get('docType'), docNumber: fd.get('docNumber').trim(),
      businessId: fd.get('businessId').trim(), notes: fd.get('notes'), status: 'ready', updatedAt: new Date().toISOString()
    });
    if (r.vat !== vatBefore) r.vatEstimated = false;
    await DB.put('receipts', r);
    await learnVendor(r);
    await load(); closeSheet(); render();
    toast('נשמר ✓');
  }

  /* זוכרים את הקטגוריה שהמשתמש בחר לכל ספק, ומחילים על קבלות עתידיות מאותו ספק */
  async function learnVendor(r) {
    if (!r.vendor) return;
    const map = await DB.getSetting('vendorCats', {});
    map[r.vendor.toLowerCase()] = r.category;
    await DB.setSetting('vendorCats', map);
  }
  async function applyLearned() {
    const map = await DB.getSetting('vendorCats', {});
    for (const r of state.receipts) {
      const c = r.vendor && map[r.vendor.toLowerCase()];
      if (c && c !== r.category && r.status !== 'ready-manual' && !r.updatedAt) { r.category = c; await DB.put('receipts', r); }
    }
  }

  async function reparse(id) {
    const r = await DB.get('receipts', id);
    const f = await DB.get('files', id);
    busy('מזהה מחדש…');
    try {
      const ex = await Extract.extract(f.blob, { onStatus: busy });
      const p = P.parse(ex.text, { vendor: r.emailFrom ? r.vendor : '', date: r.date });
      Object.assign(r, { vendor: p.vendor || r.vendor, date: p.date || r.date, total: p.total ?? r.total, vat: p.vat ?? r.vat, vatEstimated: p.vatEstimated, currency: p.currency, docNumber: p.docNumber || r.docNumber, businessId: p.businessId || r.businessId, docType: p.docType, category: p.category, text: p.text.slice(0, 20000), status: p.total == null ? 'review' : 'ready', error: '' });
      await DB.put('receipts', r);
      await load(); render(); progress(null); openReceipt(id);
    } catch (e) { toast(e.message); }
  }

  async function shareOrDownload(blob, filename, title) {
    const file = new File([blob], filename, { type: blob.type || 'application/octet-stream' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try { await navigator.share({ files: [file], title: title || filename }); return; } catch (e) { if (e.name === 'AbortError') return; }
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(file); a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  }

  function extOf(r, blob) {
    const t = (blob && blob.type) || r.mime || '';
    if (/pdf/.test(t)) return 'pdf';
    if (/png/.test(t)) return 'png';
    if (/html/.test(t)) return 'html';
    if (/text/.test(t)) return 'txt';
    return 'jpg';
  }
  function niceName(r, blob) {
    const v = (r.vendor || 'קבלה').replace(/[\\/:*?"<>|\n\r]+/g, ' ').trim().slice(0, 40);
    return (r.date || 'ללא-תאריך') + '_' + v + (r.total != null ? '_' + r.total : '') + '.' + extOf(r, blob);
  }

  /* ---------- ייצוא ---------- */
  function rangeFilter(kind) {
    const now = new Date();
    const y = now.getFullYear();
    switch (kind) {
      case 'month': return r => rMonth(r) === state.month;
      case 'prev': { const k = shiftMonth(monthKey(now), -1); return r => rMonth(r) === k; }
      case 'bimonth': {
        // תקופת דיווח דו-חודשית: ינו-פבר, מרץ-אפר...
        const m = now.getMonth(); const start = m - (m % 2) - 2; const a = monthKey(new Date(y, start, 1)), b = monthKey(new Date(y, start + 1, 1));
        return r => rMonth(r) === a || rMonth(r) === b;
      }
      case 'year': return r => rMonth(r).startsWith(String(y));
      case 'lastyear': return r => rMonth(r).startsWith(String(y - 1));
      default: return () => true;
    }
  }
  function csvFor(list) {
    const head = ['תאריך', 'ספק', 'סוג מסמך', 'מספר מסמך', 'ח.פ/עוסק', 'קטגוריה', 'סכום', 'מע"מ', 'מטבע', 'מקור', 'הערות', 'שם קובץ'];
    const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
    const rows = list.map(r => [fmtDate(r.date), r.vendor, (DOC[r.docType] || {}).name, r.docNumber, r.businessId, (CAT[r.category] || {}).name, r.docType === 'credit' && r.total ? -r.total : r.total, r.vat, r.currency, (SOURCES[r.source] || '').replace(/^\S+\s/, ''), r.notes, niceName(r)].map(q).join(','));
    return '﻿' + head.map(q).join(',') + '\r\n' + rows.join('\r\n');
  }
  function exportList() {
    const list = state.receipts.filter(rangeFilter($('#expRange').value)).sort((a, b) => (a.date || '').localeCompare(b.date || ''));
    if (!list.length) { toast('אין קבלות בטווח שנבחר'); return null; }
    return list;
  }
  function rangeLabel() { return { month: state.month, prev: 'חודש-קודם', bimonth: 'דוח-מעמ', year: 'שנה', lastyear: 'שנה-שעברה', all: 'הכול' }[$('#expRange').value]; }

  async function exportCsv() {
    const list = exportList(); if (!list) return;
    await shareOrDownload(new Blob([csvFor(list)], { type: 'text/csv;charset=utf-8' }), 'קבלות_' + rangeLabel() + '.csv', 'קבלות');
  }
  async function exportZip() {
    const list = exportList(); if (!list) return;
    busy('מכין קובץ ZIP…');
    await Extract.loadScript('vendor/jszip.min.js');
    const zip = new window.JSZip();
    zip.file('טבלת_קבלות.csv', csvFor(list));
    const used = new Set();
    for (const r of list) {
      const f = await DB.get('files', r.id);
      if (!f || !f.blob) continue;
      let name = niceName(r, f.blob), n = 1;
      while (used.has(name)) name = name.replace(/(\.\w+)$/, '_' + (++n) + '$1');
      used.add(name);
      zip.file(name, f.blob);
    }
    const blob = await zip.generateAsync({ type: 'blob' });
    progress(null);
    await shareOrDownload(blob, 'קבלות_' + rangeLabel() + '.zip', 'קבלות לרואה חשבון');
  }

  async function backup() {
    busy('יוצר גיבוי…');
    await Extract.loadScript('vendor/jszip.min.js');
    const zip = new window.JSZip();
    const files = await DB.all('files');
    zip.file('kablon.json', JSON.stringify({ app: 'kablon', version: VERSION, date: new Date().toISOString(), receipts: state.receipts, settings: { vendorCats: await DB.getSetting('vendorCats', {}) } }));
    for (const f of files) {
      if (f.blob) zip.file('files/' + f.id, f.blob);
      if (f.thumb) zip.file('thumbs/' + f.id, f.thumb);
    }
    const blob = await zip.generateAsync({ type: 'blob' });
    progress(null);
    await DB.setSetting('lastBackup', new Date().toISOString());
    await shareOrDownload(blob, 'גיבוי_קבלון_' + new Date().toISOString().slice(0, 10) + '.zip', 'גיבוי קבלון');
  }
  async function restore(file) {
    busy('משחזר…');
    try {
      await Extract.loadScript('vendor/jszip.min.js');
      const zip = await window.JSZip.loadAsync(file);
      const meta = JSON.parse(await zip.file('kablon.json').async('string'));
      let n = 0;
      for (const r of meta.receipts) {
        if (await DB.get('receipts', r.id)) continue;
        const fb = zip.file('files/' + r.id), tb = zip.file('thumbs/' + r.id);
        const blob = fb ? new Blob([await fb.async('arraybuffer')], { type: r.mime || '' }) : null;
        const thumb = tb ? new Blob([await tb.async('arraybuffer')], { type: 'image/jpeg' }) : null;
        await DB.put('files', { id: r.id, blob, thumb });
        await DB.put('receipts', r);
        n++;
      }
      if (meta.settings && meta.settings.vendorCats) await DB.setSetting('vendorCats', Object.assign(await DB.getSetting('vendorCats', {}), meta.settings.vendorCats));
      await load(); render();
      toast('שוחזרו ' + n + ' קבלות');
    } catch (e) { toast('קובץ הגיבוי לא תקין'); }
  }

  /* ---------- הסברים ---------- */
  function whatsappHelp() {
    const installed = matchMedia('(display-mode: standalone)').matches;
    openSheet(
      '<div class="sheet-head"><h2>💬 קבלות מוואטסאפ</h2><button class="icon-btn" data-act="close">✕</button></div>' +
      (installed ? '' : '<div class="card" style="background:var(--warn-soft)"><b>שלב ראשון: להתקין את קבלון בטלפון</b><p class="small" style="margin:4px 0 8px">רק אפליקציה מותקנת מופיעה ברשימת השיתוף של וואטסאפ.</p>' + (deferredInstall ? '<button class="btn full" data-act="install">התקנה עכשיו</button>' : '<p class="small" style="margin:0">בכרום: לוחצים על ⋮ (למעלה) ← <b>הוספה למסך הבית</b> ← <b>התקנה</b>.</p>') + '</div>') +
      '<div class="card"><h2>קבלה אחת</h2><ol class="steps small">' +
      '<li>בוואטסאפ, לוחצים לחיצה ארוכה על הקבלה (תמונה או PDF).</li>' +
      '<li>לוחצים על סמל השיתוף <b>⤴</b> (למעלה).</li>' +
      '<li>בוחרים <b>קבלון</b>. הקבלה נקלטת ומזוהה אוטומטית.</li></ol>' +
      '<p class="small muted" style="margin:0">אפשר לסמן כמה קבלות ביחד ולשתף את כולן בבת אחת.</p></div>' +
      '<div class="card"><h2>כל הקבלות מצ\'אט שלם</h2><p class="small" style="margin-top:0">מתאים לקבוצה או לצ\'אט שבו נשלחות אליך קבלות (למשל מספק, מרואה החשבון, או צ\'אט עם עצמך).</p><ol class="steps small">' +
      '<li>פותחים את הצ\'אט ← ⋮ ← <b>עוד</b> ← <b>ייצוא צ\'אט</b>.</li>' +
      '<li>בוחרים <b>כולל מדיה</b>.</li>' +
      '<li>בוחרים <b>קבלון</b> ברשימת השיתוף. כל התמונות וקובצי ה-PDF בצ\'אט נסרקים, וכפילויות מסוננות.</li></ol>' +
      '<p class="small muted" style="margin:0">אם קבלון לא מופיע: שומרים את הקובץ (ZIP) בטלפון, ואז ב"העלאת קובץ" בוחרים אותו.</p></div>' +
      '<div class="card"><h2>📧 גם ממייל אחר (לא Gmail)</h2><p class="small" style="margin:0">פותחים את הקבלה המצורפת באפליקציית המייל ← שיתוף ← <b>קבלון</b>.</p></div>'
    );
  }

  function addMenu() {
    openSheet(
      '<div class="sheet-head"><h2>הוספת קבלה</h2><button class="icon-btn" data-act="close">✕</button></div>' +
      '<div class="actions" style="grid-template-columns:1fr">' +
      '<button class="action" data-act="camera"><span class="ic">📷</span><span><b>צילום קבלה</b><span class="sub">מצלמים את קבלת הנייר, והפרטים מזוהים אוטומטית</span></span></button>' +
      '<button class="action" data-act="upload"><span class="ic">📄</span><span><b>העלאת קבצים</b><span class="sub">PDF, תמונות, או ZIP של צ\'אט מוואטסאפ</span></span></button>' +
      '<button class="action" data-act="gmail-scan"><span class="ic">📧</span><span><b>סריקת Gmail</b><span class="sub">מאתר אוטומטית קבלות וחשבוניות במייל</span></span></button>' +
      '<button class="action" data-act="whatsapp-help"><span class="ic">💬</span><span><b>מוואטסאפ</b><span class="sub">איך משתפים קבלות מוואטסאפ לקבלון</span></span></button>' +
      '<button class="action" data-act="manual"><span class="ic">✍️</span><span><b>הזנה ידנית</b><span class="sub">בלי קובץ — רק הפרטים</span></span></button>' +
      '</div>'
    );
  }

  async function manualEntry() {
    const id = uid();
    const today = new Date().toISOString().slice(0, 10);
    await DB.put('receipts', { id, createdAt: new Date().toISOString(), source: 'manual', kind: 'text', vendor: '', date: today, total: null, vat: null, currency: 'ILS', docType: 'receipt', category: 'other', status: 'review', text: '', notes: '' });
    await DB.put('files', { id, blob: null, thumb: null });
    await load(); render(); openReceipt(id);
  }

  /* ---------- התקנה (PWA) ---------- */
  let deferredInstall = null;
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; $('#installBtn').classList.remove('hidden'); });
  window.addEventListener('appinstalled', () => { deferredInstall = null; $('#installBtn').classList.add('hidden'); toast('קבלון הותקן ✓ עכשיו הוא יופיע בשיתוף מוואטסאפ'); });
  async function install() {
    if (!deferredInstall) { whatsappHelp(); return; }
    deferredInstall.prompt();
    await deferredInstall.userChoice;
    deferredInstall = null;
    $('#installBtn').classList.add('hidden');
    closeSheet();
  }

  /* ---------- אירועים ---------- */
  document.addEventListener('click', async e => {
    const t = e.target.closest('[data-act],[data-nav],[data-open],[data-filter],[data-cat]');
    if (!t) { if (e.target.id === 'sheetWrap') closeSheet(); return; }
    if (t.dataset.nav) { closeSheet(); go(t.dataset.nav); return; }
    if (t.dataset.open) { openReceipt(t.dataset.open); return; }
    if (t.dataset.filter) { state.filter = t.dataset.filter; render(); return; }
    if (t.dataset.cat) { state.filter = 'cat:' + t.dataset.cat; go('list'); return; }
    const act = t.dataset.act;
    const id = t.dataset.id;
    switch (act) {
      case 'month-prev': state.month = shiftMonth(state.month, -1); render(); break;
      case 'month-next': state.month = shiftMonth(state.month, 1); render(); break;
      case 'go-list': state.filter = 'all'; go('list'); break;
      case 'show-review': state.filter = 'review'; go('list'); break;
      case 'add': addMenu(); break;
      case 'close': closeSheet(); break;
      case 'camera': closeSheet(); $('#fileCamera').click(); break;
      case 'upload': closeSheet(); $('#fileUpload').click(); break;
      case 'manual': closeSheet(); setTimeout(manualEntry, 50); break;
      case 'gmail-scan': closeSheet(); gmailScan(); break;
      case 'gmail-disconnect': Gmail.disconnect(); toast('נותק מ-Gmail'); break;
      case 'whatsapp-help': whatsappHelp(); break;
      case 'install': install(); break;
      case 'export-csv': exportCsv(); break;
      case 'export-zip': exportZip(); break;
      case 'backup': backup(); break;
      case 'restore': $('#fileRestore').click(); break;
      case 'reparse': reparse(id); break;
      case 'open-file': {
        const f = await DB.get('files', id);
        if (!f || !f.blob) { toast('אין קובץ מקור לקבלה הזו'); break; }
        const u = await fileUrl(id, 'blob');
        const w = window.open(u, '_blank');
        if (!w) { const r = await DB.get('receipts', id); shareOrDownload(f.blob, niceName(r, f.blob)); }
        break;
      }
      case 'share-file': {
        const f = await DB.get('files', id); const r = await DB.get('receipts', id);
        if (f && f.blob) shareOrDownload(f.blob, niceName(r, f.blob), r.vendor);
        else if (navigator.share) navigator.share({ text: (r.vendor || '') + ' ' + money(r.total, r.currency) + ' ' + fmtDate(r.date) }).catch(() => {});
        break;
      }
      case 'delete':
        if (!confirm('למחוק את הקבלה?')) break;
        await DB.del('receipts', id); await DB.del('files', id);
        urls.forEach((u, k) => { if (k.startsWith(id + ':')) { URL.revokeObjectURL(u); urls.delete(k); } });
        await load(); closeSheet(); render(); toast('נמחק');
        break;
      case 'wipe':
        if (!confirm('למחוק את כל הקבלות וההגדרות מהטלפון? אי אפשר לבטל.')) break;
        await DB.clear('receipts'); await DB.clear('files'); await DB.clear('settings');
        await load(); render(); toast('כל הנתונים נמחקו');
        break;
    }
  });

  document.addEventListener('submit', e => { if (e.target.id === 'recForm') { e.preventDefault(); saveForm(e.target); } });
  $('#installBtn').addEventListener('click', install);
  $('#fileCamera').addEventListener('change', e => { const f = Array.from(e.target.files); e.target.value = ''; if (f.length) importFiles(f, 'camera'); });
  $('#fileUpload').addEventListener('change', e => { const f = Array.from(e.target.files); e.target.value = ''; if (f.length) importFiles(f, 'file'); });
  $('#fileRestore').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f) restore(f); });
  $('#q').addEventListener('input', e => { state.q = e.target.value; render(); });
  $('#clientId').addEventListener('change', e => DB.setSetting('clientId', e.target.value.trim()));
  $('#scanDays').addEventListener('change', e => DB.setSetting('scanDays', +e.target.value));
  $('#theme').addEventListener('change', e => { DB.setSetting('theme', e.target.value); applyTheme(e.target.value); });
  window.addEventListener('popstate', () => { if ($('#sheetWrap').classList.contains('open')) closeSheet(true); });

  // החלקה ימינה/שמאלה בין חודשים במסך הראשי
  let tx0 = null, ty0 = null;
  $('#view-home').addEventListener('touchstart', e => { tx0 = e.touches[0].clientX; ty0 = e.touches[0].clientY; }, { passive: true });
  $('#view-home').addEventListener('touchend', e => {
    if (tx0 == null) return;
    const dx = e.changedTouches[0].clientX - tx0, dy = e.changedTouches[0].clientY - ty0;
    tx0 = null;
    if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.5) { state.month = shiftMonth(state.month, dx > 0 ? 1 : -1); render(); }
  }, { passive: true });

  function applyTheme(t) { if (t) document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme; }

  /* ---------- הפעלה ---------- */
  (async function start() {
    applyTheme(await DB.getSetting('theme', ''));
    await load();
    await applyLearned();
    const v = (location.hash || '').slice(1);
    go(['home', 'list', 'settings'].includes(v) ? v : 'home');
    if ('serviceWorker' in navigator) {
      try { await navigator.serviceWorker.register('sw.js'); } catch (e) { /* ללא מצב אופליין */ }
      navigator.serviceWorker.addEventListener('message', e => { if (e.data === 'inbox') processInbox(); });
    }
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    await processInbox();
    window.__kablonReady = true;
  })();

  // לבדיקות
  window.Kablon = { importFiles, importBlob, load, state, processInbox };
})();
