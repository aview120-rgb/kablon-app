/* קבלון — זיהוי פרטים מתוך טקסט של קבלה / חשבונית (עברית + אנגלית) */
(function (root) {
  'use strict';

  const HEB_MONTHS = { 'ינואר': 1, 'פברואר': 2, 'מרץ': 3, 'מרס': 3, 'אפריל': 4, 'מאי': 5, 'יוני': 6, 'יולי': 7, 'אוגוסט': 8, 'ספטמבר': 9, 'אוקטובר': 10, 'נובמבר': 11, 'דצמבר': 12 };
  const ENG_MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };

  const CATEGORIES = [
    { id: 'food', name: 'מזון וסופר', icon: '🛒', words: ['שופרסל', 'רמי לוי', 'ויקטורי', 'יוחננוף', 'אושר עד', 'מגה', 'טיב טעם', 'חצי חינם', 'יינות ביתן', 'קרפור', 'סופר', 'מכולת', 'am:pm', 'supermarket', 'super market', 'grocery', 'פרש מרקט', 'מעדני', 'מאפייה', 'ירקות'] },
    { id: 'restaurants', name: 'מסעדות ומשלוחים', icon: '🍽️', words: ['wolt', 'וולט', 'תן ביס', '10bis', 'cibus', 'סיבוס', 'מסעדה', 'מסעדת', 'קפה', 'cafe', 'פיצה', 'בורגר', 'מקדונלד', 'ארומה', 'קופי', 'restaurant', 'uber eats', 'שווארמה', 'סושי'] },
    { id: 'fuel', name: 'דלק ורכב', icon: '⛽', words: ['פז', 'דלק', 'סונול', 'דור אלון', 'ten ', 'טן ', 'yellow', 'יילו', 'תחנת דלק', 'מוסך', 'צמיגים', 'חניה', 'פנגו', 'pango', 'סלופארק', 'cellopark', 'כביש 6', 'נתיבי איילון', 'טסט', 'רישוי'] },
    { id: 'telecom', name: 'תקשורת ואינטרנט', icon: '📱', words: ['בזק', 'פרטנר', 'סלקום', 'פלאפון', 'הוט', 'hot mobile', 'yes', 'גולן טלקום', 'רמי לוי תקשורת', 'וואלה מובייל', '012', '013', '019', 'אקספון', 'we4g', 'סיבים', 'אינטרנט'] },
    { id: 'utilities', name: 'חשמל, מים וגז', icon: '💡', words: ['חברת החשמל', 'חשמל', 'מי ', 'תאגיד מים', 'מים', 'סופרגז', 'אמישראגז', 'פזגז', 'גז', 'ארנונה', 'עירייה', 'עיריית', 'מועצה', 'ועד בית'] },
    { id: 'online', name: 'קניות אונליין', icon: '📦', words: ['amazon', 'אמזון', 'aliexpress', 'עלי אקספרס', 'ebay', 'temu', 'shein', 'ksp', 'באג', 'ivory', 'אייבורי', 'next', 'asos', 'iherb', 'zara', 'shopify', 'order confirmation', 'הזמנה מספר'] },
    { id: 'software', name: 'תוכנה ומנויים', icon: '💻', words: ['google', 'גוגל', 'apple', 'אפל', 'microsoft', 'מיקרוסופט', 'netflix', 'נטפליקס', 'spotify', 'ספוטיפיי', 'adobe', 'dropbox', 'zoom', 'canva', 'openai', 'anthropic', 'claude', 'github', 'icloud', 'youtube', 'disney', 'wix', 'godaddy', 'subscription', 'מנוי'] },
    { id: 'health', name: 'בריאות', icon: '🩺', words: ['סופר-פארם', 'סופר פארם', 'super-pharm', 'be ', 'מכבי', 'כללית', 'מאוחדת', 'לאומית', 'בית מרקחת', 'רופא', 'מרפאה', 'שיניים', 'אופטיקה', 'קופת חולים'] },
    { id: 'insurance', name: 'ביטוח ופיננסים', icon: '🛡️', words: ['ביטוח', 'הראל', 'מגדל', 'כלל', 'הפניקס', 'מנורה', 'איילון', 'ישיר', 'aig', 'ליברה', 'wobi', 'בנק', 'עמלה', 'insurance'] },
    { id: 'transport', name: 'תחבורה ונסיעות', icon: '🚌', words: ['רב-קו', 'רב קו', 'רכבת ישראל', 'גט', 'gett', 'uber', 'יאנגו', 'yango', 'מונית', 'אל על', 'el al', 'ישראייר', 'ארקיע', 'booking', 'airbnb', 'מלון', 'hotel', 'טיסה', 'flight', 'moovit', 'מוביט'] },
    { id: 'home', name: 'בית וציוד', icon: '🏠', words: ['איקאה', 'ikea', 'ace', 'הום סנטר', 'home center', 'טמבור', 'מחסני חשמל', 'שקם אלקטריק', 'ריהוט', 'כלי בית', 'אופיס דיפו', 'office depot', 'ציוד משרדי'] },
    { id: 'clothing', name: 'ביגוד והנעלה', icon: '👕', words: ['קסטרו', 'פוקס', 'fox', 'h&m', 'רנואר', 'גולף', 'אמריקן איגל', 'terminal x', 'טרמינל', 'נעליים', 'הנעלה', 'ביגוד'] },
    { id: 'education', name: 'חינוך וילדים', icon: '🎓', words: ['גן ', 'צהרון', 'חוג', 'בית ספר', 'אוניברסיטה', 'מכללה', 'שכר לימוד', 'קורס', 'udemy', 'סטימצקי', 'צומת ספרים'] },
    { id: 'donations', name: 'תרומות', icon: '🤝', words: ['תרומה', 'עמותה', 'סעיף 46', 'donation', 'צדקה', 'ע"ר'] },
    { id: 'other', name: 'אחר', icon: '🧾', words: [] }
  ];

  const DOC_TYPES = [
    { id: 'tax_invoice_receipt', name: 'חשבונית מס קבלה', re: /חשבונית\s*מס\s*[\/\-–]?\s*קבלה|tax\s*invoice\s*[\/\-]?\s*receipt/i },
    { id: 'credit', name: 'חשבונית זיכוי', re: /חשבונית\s*זיכוי|credit\s*note/i },
    { id: 'tax_invoice', name: 'חשבונית מס', re: /חשבונית\s*מס|tax\s*invoice/i },
    { id: 'receipt', name: 'קבלה', re: /קבלה|receipt|קבלת\s*תשלום/i },
    { id: 'invoice', name: 'חשבונית', re: /חשבונית|invoice|bill\b/i },
    { id: 'order', name: 'אישור הזמנה', re: /אישור\s*הזמנה|order\s*confirm|your\s*order|הזמנה\s*מס/i },
    { id: 'payment', name: 'אישור תשלום', re: /אישור\s*תשלום|payment\s*(confirm|received|successful)|התשלום\s*(התקבל|בוצע)|עסקה\s*אושרה/i }
  ];

  const KEYWORDS = ['קבלה', 'חשבונית', 'סה"כ', 'סה״כ', 'סהכ', 'לתשלום', 'מע"מ', 'מעמ', 'תאריך', 'מספר', 'עוסק', 'שולם', 'תשלום', 'מחיר', 'כמות', 'הנחה', 'כולל', 'אשראי', 'מזומן', 'לקוח'];

  const NUM = '(\\d{1,3}(?:,\\d{3})+(?:\\.\\d{1,2})?|\\d+(?:\\.\\d{1,2})?)';
  const amountRe = new RegExp(NUM, 'g');

  function toNumber(s) {
    if (s == null) return null;
    const n = parseFloat(String(s).replace(/,/g, ''));
    return isFinite(n) ? n : null;
  }

  function normalize(text) {
    return String(text || '')
      .replace(/ /g, ' ')
      .replace(/[‎‏‪-‮⁦-⁩]/g, '')
      .replace(/[״”“]/g, '"')
      .replace(/[׳’‘`]/g, "'")
      .replace(/\r/g, '')
      .replace(/[ \t]+/g, ' ');
  }

  /* PDF-ים ישראליים רבים שומרים עברית בסדר "ויזואלי" (הפוך). הופכים חזרה אם צריך. */
  function reverseLine(line) {
    const rev = Array.from(line).reverse().join('');
    // מספרים, תאריכים ומילים לועזיות חוזרים לכיוון המקורי
    return rev.replace(/[0-9A-Za-z@][0-9A-Za-z@.,:\/\-_%$€₪]*[0-9A-Za-z@]|[0-9A-Za-z@]/g, m => Array.from(m).reverse().join(''));
  }
  function keywordScore(text) {
    let s = 0;
    for (const k of KEYWORDS) if (text.indexOf(k) !== -1) s++;
    return s;
  }
  function fixVisualHebrew(text) {
    const t = normalize(text);
    if (!/[֐-׿]/.test(t)) return t;
    const reversed = t.split('\n').map(reverseLine).join('\n');
    return keywordScore(reversed) > keywordScore(t) ? reversed : t;
  }

  function validDate(y, m, d) {
    if (y < 100) y += 2000;
    if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000 || y > 2100) return null;
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (dt.getUTCMonth() !== m - 1) return null;
    return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  }

  function findDates(text) {
    const out = [];
    const push = (iso, idx) => { if (iso) out.push({ iso, idx }); };
    let m;
    const reDMY = /(?<!\d)(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4}|\d{2})(?!\d)/g;
    while ((m = reDMY.exec(text))) push(validDate(+m[3], +m[2], +m[1]), m.index);
    const reYMD = /(?<!\d)(\d{4})[\/.\-](\d{1,2})[\/.\-](\d{1,2})(?!\d)/g;
    while ((m = reYMD.exec(text))) push(validDate(+m[1], +m[2], +m[3]), m.index);
    const heb = Object.keys(HEB_MONTHS).join('|');
    const reHeb = new RegExp('(\\d{1,2})\\s*(?:ב|ל)?(' + heb + ')\\s*,?\\s*(\\d{4})', 'g');
    while ((m = reHeb.exec(text))) push(validDate(+m[3], HEB_MONTHS[m[2]], +m[1]), m.index);
    const reEng1 = /\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\.?,?\s+(\d{4})\b/gi;
    while ((m = reEng1.exec(text))) push(validDate(+m[3], ENG_MONTHS[m[2].toLowerCase()], +m[1]), m.index);
    const reEng2 = /\b(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b/gi;
    while ((m = reEng2.exec(text))) push(validDate(+m[3], ENG_MONTHS[m[1].toLowerCase()], +m[2]), m.index);
    return out;
  }

  function pickDate(text) {
    const dates = findDates(text);
    if (!dates.length) return null;
    const today = new Date().toISOString().slice(0, 10);
    const ok = dates.filter(d => d.iso <= today);
    const pool = ok.length ? ok : dates;
    // מעדיפים תאריך שמופיע ליד המילה "תאריך" / date
    const kw = /תאריך|date|issued|הופק/gi;
    let best = null, bestDist = Infinity, k;
    while ((k = kw.exec(text))) {
      for (const d of pool) {
        const dist = d.idx - k.index;
        if (dist >= -5 && dist < 60 && dist < bestDist) { best = d; bestDist = dist; }
      }
    }
    return (best || pool[0]).iso;
  }

  function detectCurrency(text) {
    const ils = (text.match(/₪|ש"ח|שח\b|ils|nis|שקל/gi) || []).length;
    const usd = (text.match(/\$|usd|us dollar/gi) || []).length;
    const eur = (text.match(/€|eur\b|euro/gi) || []).length;
    const gbp = (text.match(/£|gbp/gi) || []).length;
    const max = Math.max(ils, usd, eur, gbp);
    if (max === 0 || ils === max) return 'ILS';
    if (usd === max) return 'USD';
    if (eur === max) return 'EUR';
    return 'GBP';
  }

  function amountsInLine(line) {
    const clean = line
      .replace(/(?<!\d)\d{1,2}[\/.\-]\d{1,2}[\/.\-]\d{2,4}(?!\d)/g, ' ')   // תאריכים
      .replace(/\d{1,2}:\d{2}(:\d{2})?/g, ' ')                               // שעות
      .replace(/\d+(?:\.\d+)?\s*%/g, ' ')                                    // אחוזים
      .replace(/\d{6,}/g, ' ');                                              // מספרי חשבון / ח.פ
    const out = [];
    let m;
    amountRe.lastIndex = 0;
    while ((m = amountRe.exec(clean))) {
      const n = toNumber(m[1]);
      if (n != null && n > 0 && n < 10000000) out.push(n);
    }
    return out;
  }

  const TOTAL_STRONG = /סה"כ\s*לתשלום|סה"כ\s*כולל\s*מע"מ|סכום\s*לתשלום|לתשלום|total\s*(amount\s*)?(due|paid|incl)|amount\s*(due|paid|charged)|grand\s*total|סה"כ\s*שולם|סכום\s*העסקה|סכום\s*החיוב|חויב(ת)?\s*(ב)?סך|total\s*charged/i;
  const TOTAL_WEAK = /סה"כ|סהכ|סך\s*הכל|סך\s*הכול|total|סכום|שולם|paid|charged|יתרה\s*לתשלום/i;
  const NOT_TOTAL = /לפני\s*מע"מ|ללא\s*מע"מ|subtotal|sub-total|before\s*vat|excl|הנחה|discount|עודף|change|מע"מ\s*\d|vat\s*\d|^\s*מע"מ|^\s*vat/i;

  function pickTotal(lines) {
    const pick = (re) => {
      for (let i = lines.length - 1; i >= 0; i--) {
        const l = lines[i];
        if (!re.test(l) || NOT_TOTAL.test(l)) continue;
        let nums = amountsInLine(l);
        if (!nums.length && lines[i + 1]) nums = amountsInLine(lines[i + 1]);
        if (nums.length) return Math.max(...nums);
      }
      return null;
    };
    let t = pick(TOTAL_STRONG);
    if (t == null) t = pick(TOTAL_WEAK);
    if (t == null) {
      // ברירת מחדל: הסכום הגדול ביותר שמופיע ליד סימן מטבע
      const cur = [];
      for (const l of lines) if (/₪|ש"ח|\$|€|ils|nis|usd/i.test(l)) cur.push(...amountsInLine(l));
      if (cur.length) t = Math.max(...cur);
    }
    return t;
  }

  function pickVat(lines, total) {
    for (const l of lines) {
      if (!/מע"מ|מעמ|vat|tax\b/i.test(l)) continue;
      if (/לפני|ללא|כולל\s*מע"מ\s*$|incl|excl|before|מספר|reg|עוסק|ח\.?פ/i.test(l)) continue;
      const nums = amountsInLine(l).filter(n => total == null || n < total);
      if (nums.length) return nums[nums.length - 1];
    }
    return null;
  }

  function pickDocNumber(text) {
    const res = [
      /(?:חשבונית\s*מס\s*[\/\-]?\s*קבלה|חשבונית\s*מס|חשבונית|קבלה|מסמך|אסמכתא|תעודה)\s*(?:מס(?:פר)?|מס'|#|no\.?)?\s*[:.]?\s*([A-Z]{0,4}[\-\/]?\d{3,})/i,
      /(?:invoice|receipt|order|document|ref(?:erence)?)\s*(?:number|no\.?|num|#|id)?\s*[:#]?\s*([A-Z0-9][A-Z0-9\-\/]{3,})/i,
      /(?:מספר\s*הזמנה|מס'\s*הזמנה|הזמנה\s*מס(?:פר)?'?)\s*[:#]?\s*([A-Z0-9\-]{3,})/i
    ];
    for (const re of res) {
      const m = text.match(re);
      if (m && /\d/.test(m[1])) return m[1];
    }
    return '';
  }

  function pickBusinessId(text) {
    const m = text.match(/(?:ח\.?\s*פ\.?|ע\.?\s*מ\.?|עוסק\s*(?:מורשה|פטור)?|ע\.?\s*ר\.?|מס(?:פר)?\s*עוסק|vat\s*(?:reg(?:istration)?|no|number)|company\s*(?:no|number|id))\s*[:.#]?\s*(\d[\d\-\s]{7,11}\d)/i);
    if (m) {
      const id = m[1].replace(/\D/g, '');
      if (id.length >= 8 && id.length <= 10) return id;
    }
    return '';
  }

  const VENDOR_SKIP = /^(קבלה|חשבונית|מקור|העתק|נאמן\s*למקור|tax|invoice|receipt|לכבוד|תאריך|date|page|עמוד|דף|מס'|מספר|\d)/i;
  function pickVendor(lines, hints) {
    if (hints && hints.vendor) return hints.vendor;
    for (const l of lines.slice(0, 10)) {
      const s = l.replace(/[|*=_~]+/g, ' ').trim();
      if (s.length < 2 || s.length > 45) continue;
      if (VENDOR_SKIP.test(s)) continue;
      if (!/[A-Za-z֐-׿]{2,}/.test(s)) continue;
      if (/@|www\.|http|טל[':.]|tel|פקס|fax|רח'|רחוב|street/i.test(s)) continue;
      return s.replace(/\s+(בע"מ|בעמ|ltd\.?|inc\.?)$/i, m => m);
    }
    return '';
  }

  function guessCategory(text, vendor) {
    const hay = (' ' + (vendor || '') + ' ' + text + ' ').toLowerCase();
    let best = 'other', bestScore = 0;
    for (const c of CATEGORIES) {
      let s = 0;
      for (const w of c.words) {
        if (hay.indexOf(w.toLowerCase()) !== -1) s += (vendor && vendor.toLowerCase().indexOf(w.toLowerCase()) !== -1) ? 3 : 1;
      }
      if (s > bestScore) { best = c.id; bestScore = s; }
    }
    return best;
  }

  function guessDocType(text) {
    for (const d of DOC_TYPES) if (d.re.test(text)) return d.id;
    return 'receipt';
  }

  /* כמה הטקסט "נראה כמו קבלה" — 0 עד 1. משמש לסינון מיילים לא רלוונטיים */
  function receiptConfidence(text, result) {
    let s = 0;
    if (DOC_TYPES.some(d => d.re.test(text))) s += 0.35;
    if (result.total != null) s += 0.3;
    if (result.date) s += 0.1;
    if (result.vat != null) s += 0.1;
    if (result.docNumber) s += 0.1;
    if (result.businessId) s += 0.05;
    return Math.min(1, s);
  }

  /**
   * parse(text, hints) → { vendor, date, total, vat, vatEstimated, currency, docNumber, businessId, docType, category, confidence }
   * hints: { vendor, date } — למשל שם השולח ותאריך המייל
   */
  function parse(rawText, hints) {
    hints = hints || {};
    const text = fixVisualHebrew(rawText);
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    const total = pickTotal(lines);
    let vat = pickVat(lines, total);
    const docType = guessDocType(text);
    const currency = detectCurrency(text);
    let vatEstimated = false;
    const date = pickDate(text) || hints.date || '';
    if (vat == null && total != null && currency === 'ILS' && /tax_invoice/.test(docType)) {
      const rate = date && date < '2025-01-01' ? 0.17 : 0.18;
      vat = Math.round(total * rate / (1 + rate) * 100) / 100;
      vatEstimated = true;
    }
    const vendor = pickVendor(lines, hints);
    const result = {
      vendor,
      date,
      total,
      vat,
      vatEstimated,
      currency,
      docNumber: pickDocNumber(text),
      businessId: pickBusinessId(text),
      docType,
      category: guessCategory(text, vendor),
      text
    };
    result.confidence = receiptConfidence(text, result);
    return result;
  }

  const api = { parse, fixVisualHebrew, findDates, CATEGORIES, DOC_TYPES, guessCategory };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ReceiptParser = api;
})(typeof self !== 'undefined' ? self : this);
