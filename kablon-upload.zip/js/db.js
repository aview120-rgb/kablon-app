/* קבלון — אחסון מקומי בטלפון (IndexedDB). עובד גם בדף וגם ב-Service Worker */
(function (root) {
  'use strict';
  const DB_NAME = 'kablon';
  const VERSION = 1;
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('receipts')) {
          const s = db.createObjectStore('receipts', { keyPath: 'id' });
          s.createIndex('date', 'date');
          s.createIndex('hash', 'hash');
          s.createIndex('sourceKey', 'sourceKey');
        }
        if (!db.objectStoreNames.contains('files')) db.createObjectStore('files', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('inbox')) db.createObjectStore('inbox', { keyPath: 'id', autoIncrement: true });
        if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  function tx(store, mode, fn) {
    return open().then(db => new Promise((resolve, reject) => {
      const t = db.transaction(store, mode);
      const s = t.objectStore(store);
      let result;
      Promise.resolve(fn(s)).then(r => { result = r; });
      t.oncomplete = () => resolve(result && result.__req ? result.__req.result : result);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    }));
  }
  const wrap = req => ({ __req: req });

  const DB = {
    open,
    put: (store, value, key) => tx(store, 'readwrite', s => wrap(key === undefined ? s.put(value) : s.put(value, key))),
    get: (store, key) => tx(store, 'readonly', s => wrap(s.get(key))),
    del: (store, key) => tx(store, 'readwrite', s => wrap(s.delete(key))),
    all: (store) => tx(store, 'readonly', s => wrap(s.getAll())),
    clear: (store) => tx(store, 'readwrite', s => wrap(s.clear())),
    byIndex: (store, index, value) => tx(store, 'readonly', s => wrap(s.index(index).getAll(value))),
    getSetting: (key, def) => DB.get('settings', key).then(v => (v === undefined ? def : v)),
    setSetting: (key, value) => DB.put('settings', value, key)
  };

  root.DB = DB;
})(typeof self !== 'undefined' ? self : this);
