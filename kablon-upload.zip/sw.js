/* קבלון — Service Worker: עבודה בלי אינטרנט + קבלת קבצים ששותפו מוואטסאפ / מייל / גלריה */
importScripts('js/db.js');

const CACHE = 'kablon-v1.0.0';
const SHELL = [
  './', 'index.html', 'css/app.css', 'manifest.webmanifest',
  'js/db.js', 'js/parser.js', 'js/extract.js', 'js/gmail.js', 'js/app.js',
  'icons/icon-192.png', 'icons/icon-512.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k.startsWith('kablon-') && k !== CACHE && k !== 'kablon-vendor').map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

async function handleShare(request) {
  try {
    const form = await request.formData();
    const files = form.getAll('files').filter(f => f && typeof f === 'object' && f.size > 0);
    const text = ['title', 'text', 'url'].map(k => form.get(k)).filter(Boolean).join('\n');
    await DB.put('inbox', { at: Date.now(), files, text });
  } catch (err) { /* נמשיך לאפליקציה בכל מקרה */ }
  const clients = await self.clients.matchAll({ type: 'window' });
  clients.forEach(c => c.postMessage('inbox'));
  return Response.redirect('./index.html?share=1#home', 303);
}

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method === 'POST' && url.pathname.endsWith('/share-target')) {
    e.respondWith(handleShare(e.request));
    return;
  }
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;

  // ספריות כבדות (זיהוי טקסט, PDF) — נשמרות במטמון בפעם הראשונה ואז עובדות בלי אינטרנט
  if (url.pathname.includes('/vendor/')) {
    e.respondWith(caches.open('kablon-vendor').then(async c => {
      const hit = await c.match(e.request);
      if (hit) return hit;
      const res = await fetch(e.request);
      if (res.ok) c.put(e.request, res.clone());
      return res;
    }));
    return;
  }

  // קבצי האפליקציה: קודם רשת (כדי לקבל עדכונים), ואם אין רשת — מהמטמון
  e.respondWith((async () => {
    try {
      const res = await fetch(e.request);
      if (res.ok) (await caches.open(CACHE)).put(e.request, res.clone());
      return res;
    } catch (err) {
      const hit = await caches.match(e.request, { ignoreSearch: true });
      return hit || caches.match('index.html');
    }
  })());
});
